package com.opensymphony.xwork2.util.reflection;

import com.opensymphony.xwork2.XWorkException;

public class ReflectionException extends XWorkException {

    public ReflectionException() {
        // TODO Auto-generated constructor stub
    }

    public ReflectionException(String s) {
        super(s);
        // TODO Auto-generated constructor stub
    }

    public ReflectionException(String s, Object target) {
        super(s, target);
        // TODO Auto-generated constructor stub
    }

    public ReflectionException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    public ReflectionException(Throwable cause, Object target) {
        super(cause, target);
        // TODO Auto-generated constructor stub
    }

    public ReflectionException(String s, Throwable cause) {
        super(s, cause);
        // TODO Auto-generated constructor stub
    }

    public ReflectionException(String s, Throwable cause, Object target) {
        super(s, cause, target);
        // TODO Auto-generated constructor stub
    }

}
